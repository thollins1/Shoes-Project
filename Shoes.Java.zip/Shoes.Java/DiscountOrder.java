public class DiscountOrder extends PurchaseOrder{
      public double discount;
        
      public DiscountOrder(String storeName, double discount){
      super(storeName);
      this.discount = discount;
      }
      
      
      @Override
      public double calculateTotal(){
   double total = super.calculateTotal();
       
       return total - (total * discount);
      }

}