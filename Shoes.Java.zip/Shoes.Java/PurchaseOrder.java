import java.util.ArrayList;

public class PurchaseOrder {

   //2. arraylist of Shoe objects
   private ArrayList<Shoes> shoes = new ArrayList<>();

   //6. name of store
   private String storeName;

     //3. static order number
    private static int seqNo = 1000;
    private String orderNumber;


     public PurchaseOrder(){
     //2.arraylist of shoe objects
     shoes = new ArrayList<>();  
    orderNumber = seqNo + ""; //or orderNumber = Integer.toString(seqNo);
    seqNo++; 

 }


    //4. add method
    public void add(String style, double price){
    Shoes s = new Shoes(style, price);
    shoes.add(s);

  }

    //5. calculateTotal method
    public double calculateTotal(){
          double total = 0; // accumulator, keeps track of total
          for(Shoes s : shoes){ // for each shoe in items, represent it with s
          total += s.getPrice(); // add price od s1 to total
  }
  return total; // return total to where this method was called

}
public String toString(){
                String str = "1302 Shoes\nThank you for your purchase!\n\n";
                for (Shoes s : shoes){
                str += s + "\n";
                }
                str += "\n# Items purchased " + shoes.size();
                str += "\nTotal Price $" + String.format("%.2f", calculateTotal());
                 return str;

}

     public PurchaseOrder(String storeName){
     this.storeName = storeName;
     }
} 