import java.util.ArrayList;

public class PolyOrders{
    public static void main(String[] args){
    ArrayList<PurchaseOrder> stuff = new ArrayList<>();
        stuff.add(new PurchaseOrder("Sneaks"));
        stuff.add(new DiscountOrder("Sneaks", 0.10));
        stuff.add(new PurchaseOrder("Sneaks"));
        for(PurchaseOrder po : stuff){
        po.add("sneakers", 87.17);
      
    }
        for(PurchaseOrder po : stuff){
        System.out.println(po);

    }  
}   
}  