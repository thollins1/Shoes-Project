public class OverridingwithSuper{
  public static void main(String[] args){
       
         PurchaseOrder po = new PurchaseOrder("Sneaks");
         po.add("sneakers", 87.17);
         po.add("boots", 100.96);
         po.add("loafers", 55.16);
         
         System.out.println(po);
         
  DiscountOrder stuff = new DiscountOrder("Sneaks", 0.10);   
         stuff.add("sneakers", 87.17);
         stuff.add("boots", 100.96);
         stuff.add("loafers", 55.16);
         
         System.out.println(stuff);


  }
}  