//Tobias Hollins
//Wednesday
//Lab 1

/**
*  This class reprsents<em>shoes</em>. Shoes have a style (e.g., Boots),
* a price (the price of the boots)
*/


public class Shoes{

// Declaring instance variables
private String style;
private double price;

// Zero argumented constructor
public Shoes() {
this.style = "Boots";
this.price = 75.50;
}

// Parameterized constructor
public Shoes(String style, double price) {
this.style = style;
this.price = price;
}

public Shoes(Shoes other){
    this(other.style, other.price);
 }
    
    

public String getStyle() {
return style;
}


public void setStyle(String style) {
this.style = style;
}


public double getPrice() {
return price;
}


public void setPrice(double price) {
this.price = price;
}


//added a tostring method
/* A string representation of a Shoe. It will display the style of the shoe, the
 *  price of the shoes.
 */

public String toString(){
     return "Style :"  + style + "\n" + "Price :$" +  price;

 }
 
 /**
 * Compares two Shoe objects. If the style and price are the same,
 * then the Shoe objects are equal.
 * @param that the object to compare this Shoe against
 * @return true if style and price are the same, false otherwise
 */
 public boolean equals(Shoes that){

   //  return true;
  //    }
 // else{
    //   return false;
       
       
    //   }
        return (this.style.equals(that.style) && this.price == that.price);
   }
}
