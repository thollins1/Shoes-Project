public class PurchaseOrderDemo{




public static void main(String[] args) {
         
         PurchaseOrder po = new PurchaseOrder();
         po.add("sneakers", 87.17);
         po.add("boots", 100.96);
         po.add("loafers", 55.16);
         
         System.out.println(po);
     
      
         
         
         
         
         
}         
}